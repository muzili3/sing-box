#!/bin/sh
# ============================================================
# warp_wireproxy_alpine.sh
#
# 功能：
#   1. 自动识别 Alpine/OpenRC 或 systemd 环境
#   2. 配置 WireProxy 进程自动重启
#   3. 保留 warp y 作为 WARP 管理入口
#   4. 自动备份原配置
#
# Alpine: supervise-daemon
# systemd: Restart=always
#
# 注意：需要当前容器内具有相应服务管理权限
# ============================================================

set -u

SERVICE="wireproxy"
WIREPROXY="/usr/bin/wireproxy"
CONFIG="/etc/wireguard/proxy.conf"

DELAY=5
PERIOD=60

log() {
    printf '\n========== %s ==========\n' "$*"
}

fail() {
    echo "[错误] $*" >&2
    exit 1
}

backup_file() {
    FILE="$1"

    if [ -f "$FILE" ]; then
        BACKUP="${FILE}.bak.$(date +%Y%m%d%H%M%S)"
        cp -p "$FILE" "$BACKUP" ||
            fail "无法备份 $FILE"
        echo "已备份：$BACKUP"
    fi
}

# ------------------------------------------------------------
# 1. 基础检查
# ------------------------------------------------------------
log "1. 检查环境"

[ "$(id -u)" = "0" ] ||
    fail "请在容器内以 root 身份运行"

[ -x "$WIREPROXY" ] ||
    fail "找不到 $WIREPROXY"

[ -f "$CONFIG" ] ||
    fail "找不到 $CONFIG"

command -v warp >/dev/null 2>&1 ||
    echo "[提示] 未找到 PATH 中的 warp 命令，脚本不会执行 warp y"

echo "WireProxy：$WIREPROXY"
echo "配置文件：$CONFIG"

# ------------------------------------------------------------
# 2. 自动识别服务管理器
# ------------------------------------------------------------
log "2. 识别服务管理器"

MANAGER=""

if command -v systemctl >/dev/null 2>&1 &&
   systemctl show "$SERVICE.service" >/dev/null 2>&1; then
    MANAGER="systemd"
elif command -v rc-service >/dev/null 2>&1 &&
     [ -x /sbin/openrc-run ]; then
    MANAGER="openrc"
else
    fail "未检测到可管理 wireproxy 的 systemd 或 OpenRC"
fi

echo "检测到：$MANAGER"

# ------------------------------------------------------------
# 3A. systemd：使用 drop-in，不覆盖原始 service
# ------------------------------------------------------------
if [ "$MANAGER" = "systemd" ]; then
    log "3. 配置 systemd 自动重启"

    DROPIN_DIR="/etc/systemd/system/wireproxy.service.d"
    DROPIN="$DROPIN_DIR/override.conf"

    mkdir -p "$DROPIN_DIR" ||
        fail "无法创建 $DROPIN_DIR"

    backup_file "$DROPIN"

    TMP="$DROPIN.tmp.$$"

    cat > "$TMP" <<'SYSTEMD_EOF'
[Unit]
StartLimitIntervalSec=0

[Service]
Restart=always
RestartSec=5s
SYSTEMD_EOF

    mv "$TMP" "$DROPIN" ||
        fail "无法写入 systemd 配置"

    echo "已配置："
    cat "$DROPIN"

    systemctl daemon-reload ||
        fail "systemctl daemon-reload 失败"

    # Restart=always 对运行中的服务生效需要重新加载服务
    # 这一步会造成短暂代理中断
    systemctl restart "$SERVICE.service" ||
        fail "WireProxy 重启失败，请检查 systemctl status"

    systemctl enable "$SERVICE.service" ||
        echo "[警告] 无法设置服务开机启动"

    log "4. 验证 systemd 服务"

    systemctl status "$SERVICE.service" --no-pager ||
        echo "[警告] 服务状态异常，请查看日志"

    echo
    echo "--- 生效配置 ---"
    systemctl show "$SERVICE.service" \
        -p Restart -p RestartUSec -p ActiveState -p SubState

    echo
    echo "--- 最近日志 ---"
    journalctl -u "$SERVICE.service" -n 20 --no-pager 2>/dev/null || true
fi

# ------------------------------------------------------------
# 3B. OpenRC：使用 supervise-daemon
# ------------------------------------------------------------
if [ "$MANAGER" = "openrc" ]; then
    log "3. 配置 OpenRC 自动重启"

    INIT_FILE="/etc/init.d/wireproxy"

    [ -f "$INIT_FILE" ] ||
        fail "找不到 $INIT_FILE"

    backup_file "$INIT_FILE"

    # 停止旧服务，避免新旧监督机制同时管理同一进程
    if rc-service "$SERVICE" status >/dev/null 2>&1; then
        rc-service "$SERVICE" stop ||
            fail "停止旧服务失败"
    fi

    TMP="$INIT_FILE.tmp.$$"

    cat > "$TMP" <<'OPENRC_EOF'
#!/sbin/openrc-run

description="WireProxy for WARP"

command="/usr/bin/wireproxy"
command_args="-c /etc/wireguard/proxy.conf"

supervisor="supervise-daemon"
respawn_delay=5
respawn_max=0
respawn_period=60
OPENRC_EOF

    chmod 755 "$TMP" ||
        fail "无法设置 OpenRC 服务文件权限"

    mv "$TMP" "$INIT_FILE" ||
        fail "无法写入 OpenRC 服务文件"

    rc-update add "$SERVICE" default ||
        echo "[警告] 无法设置 OpenRC 开机启动"

    rc-service "$SERVICE" start ||
        fail "WireProxy 启动失败，请检查服务日志"

    log "4. 验证 OpenRC 服务"

    rc-service "$SERVICE" status || true
    ps | grep '[s]upervise-daemon' || true
    ps | grep '[w]ireproxy' || true
fi

# ------------------------------------------------------------
# 5. 通用端口检查
# ------------------------------------------------------------
log "5. 检查 SOCKS5 端口"

if command -v ss >/dev/null 2>&1; then
    ss -lntp 2>/dev/null | grep ':40000' ||
        echo "[提示] 暂未发现 40000 端口监听"
else
    echo "[提示] 未安装 ss，跳过端口检查"
fi

log "配置完成"

echo "服务管理器：$MANAGER"
echo "WireProxy 异常退出后将尝试自动重启。"
echo "本脚本不会执行 warp y，避免触发开关逻辑。"
echo "注意：自动重启进程不等于自动修复所有 WARP 网络故障。"
