#!/bin/bash
set -e

CONFIG="/etc/wireguard/proxy.conf"
PORT="40000"
SERVICE_FILE="/etc/systemd/system/wireproxy.service"

install_tools(){
    if ! command -v wgcf >/dev/null 2>&1; then
        echo "[+] Installing wgcf"
        chmod +x ./wgcf_2.2.32_linux_amd64
        mv ./wgcf_2.2.32_linux_amd64 /usr/local/bin/wgcf
    else
        echo "[+] wgcf already installed"
    fi

    if ! command -v wireproxy >/dev/null 2>&1; then
        echo "[+] Installing wireproxy"
        chmod +x ./wireproxy
        mv ./wireproxy /usr/bin/wireproxy
    else
        echo "[+] wireproxy already installed"
    fi
}

create_service(){
    echo "[+] Creating wireproxy service"

    cat > ${SERVICE_FILE} <<EOF
[Unit]
Description=Wireproxy WARP SOCKS5 Proxy
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=/bin/sleep 15
ExecStart=/usr/bin/wireproxy -c /etc/wireguard/proxy.conf
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
}

stop_wireproxy(){
    systemctl stop wireproxy 2>/dev/null || true
    pkill -x wireproxy 2>/dev/null || true
    sleep 2
}

start_wireproxy(){
    echo "[+] Starting wireproxy service"
    stop_wireproxy
    systemctl start wireproxy
    sleep 5
}

check_warp_ip(){
    timeout 10 curl \
    --socks5 127.0.0.1:${PORT} \
    https://www.cloudflare.com/cdn-cgi/trace \
    2>/dev/null || true
}

install_tools

create_service

while true
do
    echo "======================================"
    echo "Generating new WARP configuration"
    echo "======================================"

    stop_wireproxy

    # Generate new WARP account and proxy configuration
    sh ./wgcf_to_wireproxy.sh

    start_wireproxy

    echo "[+] Checking WARP IP"

    RESULT=$(check_warp_ip)

    if echo "$RESULT" | grep -q "ip="; then
        echo "======================================"
        echo "Current WARP information:"
        echo "======================================"
        echo "$RESULT"
    else
        echo "[!] Failed to get WARP IP"
        stop_wireproxy
        continue
    fi

    echo
    echo "Keep this IP?"
    echo "y: keep current IP and enable service"
    echo "n: generate another WARP IP"

    read -r -p "Choice [y/n]: " choice

    if [ -z "$choice" ] || [ "$choice" = "y" ] || [ "$choice" = "Y" ]; then

        echo "[+] Keeping current IP"

        stop_wireproxy

        systemctl enable wireproxy

        systemctl start wireproxy

        echo "[+] wireproxy enabled"

        systemctl status wireproxy --no-pager

        break

    else

        echo "[+] Reject current IP"

        stop_wireproxy

    fi
done