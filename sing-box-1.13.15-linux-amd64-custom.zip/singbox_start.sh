
#!/usr/bin/env bash
set -Eeuo pipefail

# ============================================================
# sing-box 安装、配置与启动脚本
# 支持 Alpine Linux（OpenRC）和 systemd Linux
# 用法：bash singbox_start.sh your.domain.com
# ============================================================

OLD_DOMAIN="vpnzlfmmeiguoxiusidun.smlt4.top"
CONFIG_SOURCE="./config.json"
CONFIG_DIR="/etc/sing-box"
CONFIG_FILE="${CONFIG_DIR}/config.json"
SERVICE_NAME="sing-box"

# 固定节点参数
VLESS_UUID="343dd7fd-8fbe-44a4-9422-537a72d4ed07"
WS_SERVER="104.25.128.0"
WS_PORT="2052"
WS_PATH="/smlt4"
REALITY_PORT="20052"
REALITY_PUBLIC_KEY="TMfp8_ugU6vkjcKI_QQ89TqRvZiKWTRLLFJBaSgnpmM"
REALITY_SNI="addons.mozilla.org"
REALITY_SHORT_ID="12345678"

log() {
    printf '\n[%s] %s\n' "$(date '+%F %T')" "$*"
}

die() {
    printf '\n[ERROR] %s\n' "$*" >&2
    exit 1
}

trap 'rc=$?; echo "[ERROR] 脚本在第 ${LINENO} 行执行失败，退出码：${rc}" >&2; exit "$rc"' ERR

# ------------------------------------------------------------
# 1. 检查参数与配置模板
# ------------------------------------------------------------
DOMAIN="${1:-}"

[[ -n "$DOMAIN" ]] || die "缺少域名参数。用法：bash singbox_start.sh your.domain.com"

if [[ ! "$DOMAIN" =~ ^[A-Za-z0-9.-]+$ ]]; then
    die "域名格式不正确：${DOMAIN}"
fi

[[ -f "$CONFIG_SOURCE" ]] || die "当前目录找不到 ${CONFIG_SOURCE}。"

log "开始部署 sing-box"
echo "目标域名：${DOMAIN}"
echo "配置模板：${CONFIG_SOURCE}"

# ------------------------------------------------------------
# 2. 检测系统并安装 sing-box
# ------------------------------------------------------------
if [[ -f /etc/alpine-release ]]; then
    OS_TYPE="alpine"

    log "检测到 Alpine Linux，使用 apk 安装 sing-box"
    apk add sing-box

    SING_BOX_BIN="$(command -v sing-box)" \
        || die "安装后找不到 sing-box 命令。"

    command -v rc-service >/dev/null 2>&1 \
        || die "未找到 rc-service。"

    [[ -f /etc/init.d/sing-box ]] \
        || die "未找到 /etc/init.d/sing-box 服务脚本。"

else
    OS_TYPE="systemd"

    log "检测到非 Alpine Linux"

    if ! command -v sing-box >/dev/null 2>&1; then
        if command -v apt-get >/dev/null 2>&1; then
            apt-get update
            apt-get install -y sing-box
        elif command -v dnf >/dev/null 2>&1; then
            dnf install -y sing-box
        elif command -v yum >/dev/null 2>&1; then
            yum install -y sing-box
        else
            die "未找到支持的软件包管理器，无法自动安装 sing-box。"
        fi
    fi

    SING_BOX_BIN="$(command -v sing-box)" \
        || die "找不到 sing-box 命令。"

    command -v systemctl >/dev/null 2>&1 \
        || die "未找到 systemctl，当前环境无法使用 systemd。"

    # 如果系统没有现成服务文件，则创建服务文件
    if [[ ! -f /etc/systemd/system/sing-box.service ]] \
        && [[ ! -f /usr/lib/systemd/system/sing-box.service ]] \
        && [[ ! -f /lib/systemd/system/sing-box.service ]]; then

        log "创建 systemd 服务文件"

        cat > /etc/systemd/system/sing-box.service <<'SERVICE'
[Unit]
Description=sing-box service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/sing-box run -c /etc/sing-box/config.json
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
SERVICE
    fi
fi

log "sing-box 程序路径：${SING_BOX_BIN}"
"$SING_BOX_BIN" version

# ------------------------------------------------------------
# 3. 生成配置文件
# ------------------------------------------------------------
log "生成 sing-box 配置文件"

mkdir -p "$CONFIG_DIR"

if [[ -f "$CONFIG_FILE" ]]; then
    cp -a "$CONFIG_FILE" "${CONFIG_FILE}.bak.$(date +%Y%m%d%H%M%S)"
    log "已备份原配置文件"
fi

# 替换模板中的旧域名
sed "s/${OLD_DOMAIN//./\\.}/${DOMAIN}/g" \
    "$CONFIG_SOURCE" > "${CONFIG_FILE}.tmp"

[[ -s "${CONFIG_FILE}.tmp" ]] || die "生成的配置文件为空。"

mv "${CONFIG_FILE}.tmp" "$CONFIG_FILE"

log "配置文件已生成：${CONFIG_FILE}"

# ------------------------------------------------------------
# 4. 检查配置
# ------------------------------------------------------------
log "检查 sing-box 配置"

"$SING_BOX_BIN" check -c "$CONFIG_FILE" \
    || die "配置检查失败，请检查 config.json 内容。"

log "配置检查通过"

# ------------------------------------------------------------
# 5. 启用并启动服务
# ------------------------------------------------------------
if [[ "$OS_TYPE" == "alpine" ]]; then

    log "启用 OpenRC 服务"
    rc-update add "$SERVICE_NAME" default

    log "启动 sing-box 服务"

    if rc-service "$SERVICE_NAME" restart; then
        :
    else
        log "restart 未成功，尝试 start"
        rc-service "$SERVICE_NAME" start
    fi

    sleep 2

    rc-service "$SERVICE_NAME" status \
        || die "sing-box 服务未正常运行，请检查服务日志。"

else

    log "重新加载 systemd 配置"
    systemctl daemon-reload

    log "启用并启动 sing-box 服务"
    systemctl enable --now "$SERVICE_NAME"

    sleep 2

    systemctl --no-pager --full status "$SERVICE_NAME" \
        || die "sing-box 服务未正常运行，请检查 systemd 日志。"
fi

# ------------------------------------------------------------
# 6. 输出节点信息
# ------------------------------------------------------------
log "部署流程完成"

echo ""
echo "========================================"
echo "          sing-box 节点信息"
echo "========================================"

echo ""
echo "VLESS WS:"
echo "vless://${VLESS_UUID}@${WS_SERVER}:${WS_PORT}?security=&type=ws&path=%2Fsmlt4&host=${DOMAIN}&encryption=none#vless-ws"

echo ""
echo "VLESS Reality:"
echo "vless://${VLESS_UUID}@${DOMAIN}:${REALITY_PORT}?type=tcp&security=reality&pbk=${REALITY_PUBLIC_KEY}&fp=chrome&sni=${REALITY_SNI}&flow=xtls-rprx-vision&sid=${REALITY_SHORT_ID}&encryption=none#vless-reality"

echo ""
echo "Listening ports:"
if command -v ss >/dev/null 2>&1; then
    ss -tulnp | grep sing-box || true
else
    echo "ss command not found; skipping port listing"
fi

echo ""
echo "配置文件：${CONFIG_FILE}"
echo "sing-box 路径：${SING_BOX_BIN}"

if [[ "$OS_TYPE" == "alpine" ]]; then
    echo "查看服务状态：rc-service sing-box status"
    echo "查看进程：ps | grep '[s]ing-box'"
else
    echo "查看服务状态：systemctl status sing-box"
    echo "查看日志：journalctl -u sing-box -n 100 --no-pager"
fi

echo ""
echo "Done."
