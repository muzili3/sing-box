#!/bin/bash
set -e

DOMAIN=$1

if [ -z "$DOMAIN" ]; then
    echo "Usage: ./start.sh domain.com"
    exit 1
fi

echo "Installing sing-box..."
echo "Domain: $DOMAIN"

if [ ! -f "./sing-box" ]; then
    echo "Error: sing-box binary not found"
    exit 1
fi

if [ ! -f "./config.json" ]; then
    echo "Error: config.json not found"
    exit 1
fi

if [ -f /etc/alpine-release ]; then
echo "检测到 Alpine Linux，使用 apk 安装 sing-box..."
apk add sing-box
else
echo "非 Alpine Linux，使用本地 sing-box 二进制文件..."
if [ ! -f "./sing-box" ]; then
    echo "Error: sing-box binary not found"
    exit 1
fi
cp ./sing-box /usr/local/bin/sing-box
chmod +x /usr/local/bin/sing-box
fi

mkdir -p /etc/sing-box

sed "s/vpnzlfmmeiguoxiusidun.smlt4.top/$DOMAIN/g" ./config.json > /etc/sing-box/config.json

echo "Checking configuration..."
sing-box check -c /etc/sing-box/config.json

cat > /etc/systemd/system/sing-box.service <<EOF
[Unit]
Description=sing-box
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/sing-box run -c /etc/sing-box/config.json
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sing-box
systemctl restart sing-box

sleep 2

if systemctl is-active --quiet sing-box; then
    echo ""
    echo "sing-box started successfully"
    echo ""
    echo "VLESS WS:"
    echo "vless://343dd7fd-8fbe-44a4-9422-537a72d4ed07@t31.cloudflare.182682.xyz:2052?security=&type=ws&path=/smlt4&host=$DOMAIN&encryption=none#vless-ws"
    echo ""
    echo "VLESS Reality:"
    echo "vless://343dd7fd-8fbe-44a4-9422-537a72d4ed07@$DOMAIN:20052?type=tcp&security=reality&pbk=TMfp8_ugU6vkjcKI_QQ89TqRvZiKWTRLLFJBaSgnpmM&fp=chrome&sni=addons.mozilla.org&flow=xtls-rprx-vision&sid=12345678&encryption=none#vless-reality"
    echo ""
    echo "Listening ports:"
    ss -tulnp | grep sing-box || true
else
    echo "sing-box failed"
    journalctl -u sing-box --no-pager -n 30
    exit 1
fi