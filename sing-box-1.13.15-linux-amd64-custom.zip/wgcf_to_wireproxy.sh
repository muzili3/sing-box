#!/bin/bash
set -e
echo "===== 生成新的 WARP WireGuard 配置 ====="
# 停止 wireproxy
systemctl stop wireproxy 2>/dev/null || true
# 备份旧配置
if [ -f /etc/wireguard/proxy.conf ]; then
    cp /etc/wireguard/proxy.conf \
    /etc/wireguard/proxy.conf.backup.$(date +%F-%H%M%S)
fi
echo "===== 删除旧 wgcf 身份 ====="
rm -f wgcf-account.toml
rm -f wgcf-profile.conf
echo "===== 注册新的 WARP 账号 ====="
wgcf register --accept-tos
echo "===== 生成 WireGuard 配置 ====="
wgcf generate
echo "===== 转换为 wireproxy 配置 ====="
mkdir -p /etc/wireguard
# 提取 Interface
awk '
/^\[Interface\]/ {flag=1;print;next}
/^\[Peer\]/ {flag=0}
flag
' wgcf-profile.conf > /etc/wireguard/proxy.conf
# 提取 Peer
awk '
/^\[Peer\]/ {flag=1}
flag
' wgcf-profile.conf >> /etc/wireguard/proxy.conf
# 添加 Socks5
cat >> /etc/wireguard/proxy.conf <<EOF
[Socks5]
BindAddress = 127.0.0.1:40000
